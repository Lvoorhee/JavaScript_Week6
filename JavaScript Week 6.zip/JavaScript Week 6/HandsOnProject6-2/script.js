// Hands-On Project 6-2
// Lucas Voorhees
// 12/4/20

"use strict";
var formValidity = true;

/* validate required fields */
function validateRequired() {
	var inputElements = document.querySelectorAll("#contactinfo input");
	var errorDiv = document.getElementById("errorText");
	var elementCount = inputElements.length;
	var requiredValidity = true;
	var currentElement;

	try {
		for (var i = 0; i < elementCount; i++) {
			currentElement = inputElements[i];

		if (currentElement.value === "") {
			currentElement.style.background = "rgb(255,233,233)";
			requiredValidity = false;

		} else {
			currentElement.style.background = "white";
		}
	}
		if (requiredValidity === false) {
		throw "Please complete all fields.";
	}
			errorDiv.style.display = "none";
			errorDiv.innerHTML = "";
	}
		catch(msg) {
			errorDiv.style.display = "block";
			errorDiv.innerHTML = msg;
			formValidity = false;
		}
	}

function validateForm(evt) {

		if (evt.preventDefault) {
			evt.preventDefault();

		} else {
			evt.returnValue = false;
		}
			formValidity = true;
			validateRequired();

		if (formValidity === true) {
			document.getElementsByTagName("form")[0].submit();
		}
	}

/* remove fallback placeholder text */
function zeroPlaceholder() {
	var addressBox = document.getElementById("addrinput");
	addressBox.style.color = "black";
	if (addressBox.value === addressBox.placeholder) {
		addressBox.value = "";
	}
}

/* Restore placeholder text if box conains no user entry */
function checkPlaceholder() {
	var addressBox = element.getElementById("addrinput");
	if (addressBox.value === "") {
		addressBox.style.color = "rgb(178,184,183)";
		addressBox.value = addressBox.placeholder;
	}
}

/* add placeholder text for browsers that don't support placeholder attribute */
function generatePlaceholder() {
	if (!Modernizr.input.placeholder) {
		var addressBox = document.getElementById("addrinput");
		addressBox.value = addressBox.placeholder;
		addressBox.style.color = "rgb(178,184,183)";
		if (addressBox.addEventListener) {
			addressBox.addEventListener ("focus", zeroPlaceholder, false);
			addressBox.addEventListener ("blur", checkPlaceholder, false);
		} else if (addressBox.attachEvent) {
			addressBox.attachEvent ("onfocus", zeroPlaceholder);
			addressBox.attachEvent ("onblur", checkPlaceholder);
		}
	}
}

/* run initial form configuration functions */
function setUpPage() {
	createEventListeners();
	generatePlaceholder();
}

function createEventListeners() { 
	if (window.addEventListener) {
		window.addEventListener("load", setUpPage, false);
	} else if (window.attachEvent) {
		window.attachEvent("onload", setUpPage);
	}
}


        